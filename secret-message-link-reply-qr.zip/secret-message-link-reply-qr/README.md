# Secret Message Link + Reply + QR

Static web app for creating shareable secret-message links with:
- Custom text message
- Optional song link (YouTube / Spotify / etc.)
- Contact info (Facebook, Instagram, LINE ID)
- View counter using countapi.xyz + localStorage
- Reply feature: recipient can generate a reply link
- QR code generation for both main link and reply link
- Convenience button to open an external URL shortener site (e.g. bitly)

## How it works

- In CREATE mode:
  - User types a message, optional song URL, and contact links.
  - App encodes the data into the URL query string (?d=...).
  - App shows:
    - A shareable link (you can copy)
    - A QR code generated with qrcodejs
    - A button that opens bitly.com for manual URL shortening.

- In VIEW mode:
  - Visitor sees the decoded message, song link button, and contact chips.
  - A view counter shows approximate unique views (per browser/device).
  - A "Reply" section allows the visitor to:
    - Type a reply message
    - Add their own song link and contact info
    - Generate a new reply link (with its own QR code)
    - Copy that reply link and send it back via chat.

All logic is client-side only. Suitable for GitHub Pages or any static hosting.

## Deploy on GitHub Pages

1. Create a new **public** repository on GitHub, e.g. `secret-message-link-reply-qr`.
2. Upload `index.html` (and this `README.md` if you want).
3. Go to **Settings → Pages**.
4. Under **Source**, select:
   - `Deploy from a branch`
   - Branch: `main`
   - Folder: `/ (root)`
5. Save and wait for deployment.
6. GitHub will provide a URL like:

   `https://<username>.github.io/<repository-name>/`

Use that URL to start creating and sharing secret messages with reply + QR.
